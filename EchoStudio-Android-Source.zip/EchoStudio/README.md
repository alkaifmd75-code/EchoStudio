# Echo Studio (Android)

Native Kotlin Android starter project with:
- Real-time microphone echo through AudioRecord + AudioTrack
- Live controls: delay (40–1200 ms), feedback (0–88%), wet/echo level (0–100%)
- Dry microphone take capture while live monitoring the echo
- Import 16-bit PCM WAV (mono or stereo), apply echo, and export a mono WAV
- Pakistani Naat Echo starting preset

## Build APK on a computer
1. Open this folder in Android Studio (Android Gradle Plugin 8.7.3).
2. Install Android SDK 35 and allow Gradle sync.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## Build APK using only a phone (GitHub Actions)
1. Create a GitHub account or sign in at https://github.com.
2. Create a **public** repository named `EchoStudio` (public makes the workflow easiest to access; do not upload secrets).
3. Extract this ZIP on your phone, open the `EchoStudio` folder, and upload its contents to the repository. Make sure `.github/workflows/build-apk.yml` is included. If the GitHub mobile page hides dot-folders, use the browser's Desktop site mode.
4. In the repository, open **Actions** > **Build Echo Studio APK** > **Run workflow**.
5. When the run finishes successfully, open that run and download the **EchoStudio-debug-apk** artifact.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. Allow installation from that browser/file manager if Android asks.

## Notes / limitations
- Live echo is real-time software monitoring. Use wired headphones to prevent acoustic feedback; Bluetooth can add noticeable latency.
- Imported audio processing currently accepts 16-bit PCM WAV (mono or stereo). Other formats should first be converted to PCM WAV.
- The live recording is saved as a dry PCM take in the app cache. Export applies the current echo settings and writes a standard mono WAV.
- Audio hardware latency varies by Android device. The project has not yet been built or device-tested here.
