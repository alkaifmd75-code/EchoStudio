package com.arsh.echostudio

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val engine = EchoEngine()
    private val io = Executors.newSingleThreadExecutor()
    private var selectedUri: Uri? = null
    private var lastRaw: File? = null
    private lateinit var status: TextView
    private lateinit var delay: SeekBar
    private lateinit var feedback: SeekBar
    private lateinit var wet: SeekBar
    private lateinit var delayValue: TextView
    private lateinit var feedbackValue: TextView
    private lateinit var wetValue: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 10, 15); window.navigationBarColor = Color.rgb(8, 10, 15)
        buildUi()
    }

    private fun buildUi() {
        val bg = Color.rgb(9, 11, 16); val panel = Color.rgb(22, 26, 34); val gold = Color.rgb(231, 184, 91); val white = Color.WHITE; val muted = Color.rgb(165, 172, 184)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(20, 24, 20, 24) }
        val scroll = ScrollView(this); val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val brand = TextView(this).apply { text = "DD • ECHO STUDIO"; textSize = 12f; letterSpacing = .22f; setTextColor(gold); gravity = Gravity.CENTER }
        content.addView(brand, lp(-1, 28))
        val title = TextView(this).apply { text = "Digital Delay"; textSize = 30f; setTextColor(white); gravity = Gravity.CENTER; setPadding(0, 8, 0, 2) }
        content.addView(title, lp(-1, 48))
        val sub = TextView(this).apply { text = "LIVE VOICE PROCESSOR  •  44.1 kHz"; textSize = 10f; letterSpacing = .12f; setTextColor(muted); gravity = Gravity.CENTER }
        content.addView(sub, lp(-1, 26))
        status = TextView(this).apply { text = "● READY — headphones recommended"; textSize = 12f; setTextColor(gold); gravity = Gravity.CENTER; setPadding(8, 12, 8, 12) }
        content.addView(status, lp(-1, 42))
        val live = Button(this).apply { text = "●  START LIVE ECHO"; setTextColor(Color.BLACK); setBackgroundColor(gold); setOnClickListener { startLive() } }
        content.addView(live, lp(-1, 54))
        val stop = Button(this).apply { text = "■  STOP LIVE / SAVE DRY TAKE"; setOnClickListener { engine.stop(); status.text = "● STOPPED — take saved for processing" } }
        content.addView(stop, lp(-1, 48))
        addSection(content, "EFFECT CONTROLS", panel, white)
        delayValue = addSlider(content, "DELAY TIME", "320 ms", 40, 1200, 320, gold) { v -> engine.delayMs = v; delayValue.text = "$v ms" }.first
        delay = lastSeek!!
        feedbackValue = addSlider(content, "FEEDBACK", "42%", 0, 88, 42, gold) { v -> engine.feedback = v / 100f; feedbackValue.text = "$v%" }.first
        feedback = lastSeek!!
        wetValue = addSlider(content, "ECHO LEVEL / WET", "48%", 0, 100, 48, gold) { v -> engine.wet = v / 100f; wetValue.text = "$v%" }.first
        wet = lastSeek!!
        val preset = Button(this).apply { text = "✦  PAKISTANI NAAT ECHO PRESET"; setOnClickListener { delay.progress = 430; feedback.progress = 55; wet.progress = 43; status.text = "● NAAT PRESET APPLIED" } }
        content.addView(preset, lp(-1, 48))
        addSection(content, "RECORDING / EXPORT", panel, white)
        val pick = Button(this).apply { text = "OPEN AUDIO FILE (PCM WAV)"; setOnClickListener { val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "audio/*"; addCategory(Intent.CATEGORY_OPENABLE) }; startActivityForResult(i, 10) } }
        content.addView(pick, lp(-1, 48))
        val export = Button(this).apply { text = "EXPORT ECHO AS WAV"; setOnClickListener { createExport() } }
        content.addView(export, lp(-1, 48))
        val note = TextView(this).apply { text = "Tip: Live echo में headphones लगाएँ ताकि speaker feedback न हो. File processing के लिए 16-bit PCM WAV इस्तेमाल करें."; setTextColor(muted); textSize = 11f; setPadding(4, 14, 4, 12) }
        content.addView(note, lp(-1, -2))
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(root)
    }

    private var lastSeek: SeekBar? = null
    private fun addSection(parent: LinearLayout, text: String, panel: Int, fg: Int) {
        val t = TextView(this).apply { this.text = text; setTextColor(fg); textSize = 11f; letterSpacing = .16f; setPadding(14, 14, 14, 10); setBackgroundColor(panel) }
        val p = LinearLayout.LayoutParams(-1, -2); p.topMargin = 18; parent.addView(t, p)
    }
    private fun addSlider(parent: LinearLayout, name: String, initial: String, min: Int, max: Int, value: Int, tint: Int, change: (Int) -> Unit): Pair<TextView, SeekBar> {
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 10, 14, 4); setBackgroundColor(Color.rgb(22,26,34)) }
        val labels = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val l = TextView(this).apply { text = name; setTextColor(Color.LTGRAY); textSize = 10f }
        val v = TextView(this).apply { text = initial; setTextColor(tint); textSize = 12f; gravity = Gravity.RIGHT }
        labels.addView(l, LinearLayout.LayoutParams(0, -2, 1f)); labels.addView(v, lp(80, -2)); row.addView(labels)
        val s = SeekBar(this).apply { this.max = max - min; progress = value - min; progressTintList = android.content.res.ColorStateList.valueOf(tint); thumbTintList = android.content.res.ColorStateList.valueOf(tint); setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(sb: SeekBar?, p: Int, user: Boolean) { change(p + min) }; override fun onStartTrackingTouch(sb: SeekBar?) {}; override fun onStopTrackingTouch(sb: SeekBar?) {} }) }
        row.addView(s); parent.addView(row, lp(-1, -2)); lastSeek = s
        return Pair(v, s)
    }
    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h).apply { if (h > 0) bottomMargin = 5 }

    private fun startLive() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 5); return }
        val f = File(cacheDir, "live_take_${System.currentTimeMillis()}.pcm"); lastRaw = f
        engine.start(f) { msg -> runOnUiThread { status.text = "● $msg" } }
        status.text = "● LIVE ECHO RUNNING — speak into mic"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) { super.onRequestPermissionsResult(requestCode, permissions, grantResults); if (requestCode == 5 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startLive() else status.text = "Microphone permission जरूरी है" }

    @Deprecated("Activity result API kept minimal for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && requestCode == 10) { selectedUri = data?.data; status.text = "● AUDIO FILE SELECTED" }
        if (resultCode == RESULT_OK && requestCode == 11) { val uri = data?.data ?: return; exportTo(uri) }
    }

    private fun createExport() {
        if (selectedUri == null && lastRaw == null) { status.text = "पहले WAV फाइल चुनें या Live take रिकॉर्ड करें"; return }
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "audio/wav"; putExtra(Intent.EXTRA_TITLE, "EchoStudio_Export.wav") }
        startActivityForResult(i, 11)
    }

    private fun exportTo(uri: Uri) {
        status.text = "● PROCESSING AUDIO…"
        io.execute {
            try {
                val pcm = if (selectedUri != null) contentResolver.openInputStream(selectedUri!!).use { WavEcho.read(it!!) }
                else {
                    val bytes = lastRaw!!.readBytes(); val samples = ShortArray(bytes.size / 2) { i -> ((bytes[i*2].toInt() and 255) or (bytes[i*2+1].toInt() shl 8)).toShort() }
                    WavEcho.Pcm(samples, 44100)
                }
                contentResolver.openOutputStream(uri).use { WavEcho.writeWithEcho(pcm, it!!, engine.delayMs, engine.feedback, engine.wet) }
                runOnUiThread { status.text = "● WAV EXPORT COMPLETE" }
            } catch (e: Exception) { runOnUiThread { status.text = "● EXPORT ERROR: ${e.message}" } }
        }
    }

    override fun onDestroy() { engine.stop(); io.shutdown(); super.onDestroy() }
}
