package com.arsh.echostudio

import android.media.*
import android.os.Process
import java.io.*
import kotlin.math.max

/** Real-time mono echo engine. The dry microphone signal is also captured as 16-bit PCM. */
class EchoEngine {
    @Volatile var delayMs = 320
    @Volatile var feedback = 0.42f
    @Volatile var wet = 0.48f
    @Volatile private var running = false
    private var worker: Thread? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var rawFile: File? = null

    fun start(output: File, onError: (String) -> Unit) {
        if (running) return
        val rate = 44100
        val minIn = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val minOut = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minIn <= 0 || minOut <= 0) { onError("इस फोन पर audio input/output उपलब्ध नहीं है।"); return }
        try {
            val input = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minIn * 2, 4096))
            val out = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(max(minOut * 2, 4096)).setTransferMode(AudioTrack.MODE_STREAM).build()
            recorder = input; player = out; rawFile = output
            running = true
            input.startRecording(); out.play()
            worker = Thread {
                Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
                val buffer = ShortArray(1024)
                val delay = FloatArray(rate * 2)
                var write = 0
                try {
                    FileOutputStream(output).use { file ->
                        while (running) {
                            val n = input.read(buffer, 0, buffer.size, AudioRecord.READ_BLOCKING)
                            if (n <= 0) continue
                            val outBuf = ShortArray(n)
                            val d = (delayMs.coerceIn(40, 1200) * rate / 1000).coerceIn(1, delay.size - 1)
                            val fb = feedback.coerceIn(0f, 0.88f)
                            val mix = wet.coerceIn(0f, 1f)
                            for (i in 0 until n) {
                                val x = buffer[i] / 32768f
                                val read = (write - d + delay.size) % delay.size
                                val echo = delay[read]
                                delay[write] = (x + echo * fb).coerceIn(-1.5f, 1.5f)
                                write = (write + 1) % delay.size
                                val y = (x * (1f - mix) + echo * mix).coerceIn(-1f, 1f)
                                outBuf[i] = (y * 32767f).toInt().toShort()
                            }
                            // Keep an unprocessed recording for later editing/export.
                            val bytes = ByteArray(n * 2)
                            for (i in 0 until n) { bytes[i * 2] = (buffer[i].toInt() and 0xff).toByte(); bytes[i * 2 + 1] = (buffer[i].toInt() shr 8).toByte() }
                            file.write(bytes)
                            out.write(outBuf, 0, n, AudioTrack.WRITE_BLOCKING)
                        }
                    }
                } catch (_: Exception) { }
            }.also { it.start() }
        } catch (e: Exception) { running = false; onError(e.message ?: "Audio start नहीं हो पाया") }
    }

    fun stop() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { worker?.join(1500) } catch (_: Exception) {}
        try { player?.pause(); player?.flush(); player?.stop() } catch (_: Exception) {}
        recorder?.release(); player?.release(); recorder = null; player = null; worker = null
    }
}
