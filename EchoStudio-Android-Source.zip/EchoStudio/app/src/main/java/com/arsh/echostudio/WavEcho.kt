package com.arsh.echostudio

import java.io.*
import kotlin.math.roundToInt

object WavEcho {
    data class Pcm(val samples: ShortArray, val sampleRate: Int)

    fun read(input: InputStream): Pcm {
        val bytes = input.readBytes()
        require(bytes.size >= 44 && String(bytes, 0, 4) == "RIFF" && String(bytes, 8, 4) == "WAVE") { "कृपया PCM WAV फाइल चुनें।" }
        var pos = 12; var channels = 1; var rate = 44100; var bits = 16; var dataStart = -1; var dataSize = 0
        while (pos + 8 <= bytes.size) {
            val id = String(bytes, pos, 4, Charsets.US_ASCII)
            val size = leInt(bytes, pos + 4).coerceAtLeast(0)
            val start = pos + 8
            if (start + size > bytes.size) break
            if (id == "fmt ") {
                val format = leShort(bytes, start)
                require(format == 1) { "केवल PCM WAV फाइल समर्थित है।" }
                channels = leShort(bytes, start + 2); rate = leInt(bytes, start + 4); bits = leShort(bytes, start + 14)
            } else if (id == "data") { dataStart = start; dataSize = size; break }
            pos = start + size + (size and 1)
        }
        require(dataStart >= 0 && bits == 16 && channels in 1..2) { "16-bit mono/stereo PCM WAV चुनें।" }
        val frames = dataSize / (2 * channels); val samples = ShortArray(frames)
        for (i in 0 until frames) {
            var sum = 0
            for (c in 0 until channels) sum += leShort(bytes, dataStart + (i * channels + c) * 2).toShort().toInt()
            samples[i] = (sum / channels).toShort()
        }
        return Pcm(samples, rate)
    }

    fun writeWithEcho(pcm: Pcm, output: OutputStream, delayMs: Int, feedback: Float, wet: Float) {
        val rate = pcm.sampleRate
        val delaySamples = (delayMs.coerceIn(40, 1200) * rate / 1000).coerceAtLeast(1)
        val echoLine = FloatArray(delaySamples)
        val fb = feedback.coerceIn(0f, 0.88f); val mix = wet.coerceIn(0f, 1f)
        val out = BufferedOutputStream(output)
        val dataBytes = pcm.samples.size * 2
        out.write("RIFF".toByteArray()); putInt(out, 36 + dataBytes); out.write("WAVEfmt ".toByteArray()); putInt(out, 16)
        putShort(out, 1); putShort(out, 1); putInt(out, rate); putInt(out, rate * 2); putShort(out, 2); putShort(out, 16)
        out.write("data".toByteArray()); putInt(out, dataBytes)
        var cursor = 0
        for (sample in pcm.samples) {
            val x = sample / 32768f; val e = echoLine[cursor]
            echoLine[cursor] = (x + e * fb).coerceIn(-1.5f, 1.5f)
            val y = (x * (1f - mix) + e * mix).coerceIn(-1f, 1f)
            val v = (y * 32767f).roundToInt(); out.write(v and 255); out.write((v shr 8) and 255)
            cursor = (cursor + 1) % delaySamples
        }
        out.flush()
    }

    private fun leShort(b: ByteArray, p: Int) = (b[p].toInt() and 255) or ((b[p + 1].toInt() and 255) shl 8)
    private fun leInt(b: ByteArray, p: Int) = (b[p].toInt() and 255) or ((b[p+1].toInt() and 255) shl 8) or ((b[p+2].toInt() and 255) shl 16) or (b[p+3].toInt() shl 24)
    private fun putInt(o: OutputStream, v: Int) { repeat(4) { o.write((v ushr (8 * it)) and 255) } }
    private fun putShort(o: OutputStream, v: Int) { o.write(v and 255); o.write((v ushr 8) and 255) }
}
